nope, je hebt geen mail

Je leest nostalgisch een mail van je ex, nog een dringende mail van je baas, maar voor de rest, nope, geen mail...

[Het bos](../bos/donker-bos.md) dan maar? 

... of [klimmen over het hek](../over-het-hek/hek.md)?