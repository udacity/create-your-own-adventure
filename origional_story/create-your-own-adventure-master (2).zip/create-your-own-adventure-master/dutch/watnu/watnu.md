Wat een probleem! Hoe kan ik nu aan nieuwe stroopwafels komen?

Stroopwafels.. Ja, ik will stroopwafels. En ook dropjes !!!