Je denk terug aan je jeugd, de hoeveelheid zakken chips die nodig waren om je dorst voor flippo's te verzadigen. 

Langzaam neem je één van de flippo's tussen je vingers en...

[Je scheert hem een rot eind weg](scheer/scheer.md)

[Je eet hem op](eet/eet.md) Je had in de cosmo gelezen dat droog karton het beste helpt tegen een kater. 