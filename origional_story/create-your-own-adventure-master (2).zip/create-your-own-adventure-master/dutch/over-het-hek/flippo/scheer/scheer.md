De flippo gaat best hard, even waan je jezelf een olympisch atleet,
maar snel bezef je dat het hier maar om een stuk karton half 
zo groot als een bierviltje gaat. Even was het leuk. 