Je druk op het knopje van je mobiel, het scherm licht nog even op en...

...heb jij weer, 'Battery too low' en het scherm dimt, maar in het laatste schijnsel
zie je nog net een schim vlakbij voor je langs bewegen, wat is dit nu weer??

De schim vervolgt zijn weg zonder je op te merken. In der verte verschijnt een [lichtje](lichtje/lichtje.md).