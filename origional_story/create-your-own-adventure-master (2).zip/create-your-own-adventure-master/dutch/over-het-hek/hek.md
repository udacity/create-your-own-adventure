... vol overgave neem je een aanloop en springt over het hek. Met een elegante zwaai vlieg je eroverheen.

Nou ja... bijna dan. Net voordat je voeten de grond raken kom je plots tot stilstand.
De tranen springen je in de ogen, want het gevoel van hoe je kleren plotseling
 in je vel knijpen is niet bepaald prettig.

Terwijl de pijn langzaam wegebt, besef je wat er aan de hand is. Je zit vast!

Je zoekt naar hulpmiddelen om los te komen in je zakken en ... wat vind je?

[Het mobiel dat je eerder gevonden had](mobiel/mobiel.md)

[Wat onbekende paddestoelen; terwijl je verder droomt eet je ze op](hek.md)

[Je autosleutel](sleutel/sleutel.md)

[Een paar flippo's uit de jaren '90](flippo/flippo.md)

[Een Zwitsers zakmes](zakmes/zakmes.md)
