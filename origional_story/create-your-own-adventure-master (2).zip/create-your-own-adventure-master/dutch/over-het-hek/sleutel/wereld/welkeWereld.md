Asjemenou, terwijl je dit gebeuren overdenkt vergaat de wereld onder je voeten en wat verschijnt daar?

Sterren! Waar je ook kijkt zie je sterren in alle kleuren, geuren en maten.