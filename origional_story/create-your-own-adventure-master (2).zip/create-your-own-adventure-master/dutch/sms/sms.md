... het is een sms van een nummer dat je niet kent.
Een sms, wanneer krijg je nou nog een sms?
Het was niet van de overheid, niet van oma. 
Toch maar klikken.
En toen kwam de schok...
[Wat nu](../watnu/watnu.md)?

 