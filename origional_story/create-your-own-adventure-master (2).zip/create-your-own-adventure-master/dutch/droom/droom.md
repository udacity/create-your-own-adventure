Maar dan verandert de droom. 
De letters veranderen in getallen en je wordt plotseling geconfronteerd met moelijke sommen als: 
hoeveel is drie tankstations gedeeld door vier bomen maal een lekke fietsband?
Toch maar liever wakker worden? Maar waar raak je dan verzeild?
