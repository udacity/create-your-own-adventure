Je volgt de verlaten weg ongeveer een uur richting het noorden.
Je ziet een dorp in de verte opdoemen.
Even later blijkt dat je terug bent bij de laatste kroeg van de kroegentocht.

Dorstig van de wandeling besluit je daar maar een biertje te nemen. 
