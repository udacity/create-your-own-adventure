In het donkere bos aangekomen, hoor je plotseling stemmen.
Je verstaat geen woord ervan, maar de stemmen komen wel steeds sneller naar je toe.

Je verstopt je in de struiken, en ziet twee mannen met een lijkzak sleuren.
De grootste kijkt achterdochtig op als er een vogel opvliegt uit een boom vlak bij je schuilplaats. 

Je gaat snel [terug naar de hei](../welkom.md)

Je blijft stiekem [meekijken](ontvoering/ontvoering.md)

Je kijkt rond in de [struiken](struiken/in_de_struiken.md)

Je wandelt nog even door en komt op een [verlaten weg](verlaten-weg/verlaten-weg.md) terecht.