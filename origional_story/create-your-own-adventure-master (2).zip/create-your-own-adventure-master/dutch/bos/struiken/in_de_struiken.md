Je ligt in de struiken en kijkt rond. De takken prikken in je rug.

Je [plukt een bes](bes/bes.md).

Je besluit geen bes te plukken en gaat [verder in het bos](../donker-bos.md).