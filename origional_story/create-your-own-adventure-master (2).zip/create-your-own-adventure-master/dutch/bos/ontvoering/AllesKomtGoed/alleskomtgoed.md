Je wordt de volgende dag met een kater wakker in [de hei](../../../welkom.md).
