De mannen accepteren argwanend je hulp.

Een sterke man kunnen ze goed gebruiken omdat de lijkzak erg zwaar is. 

Ze houden je goed in de gaten, hoe red je je nou uit deze situatie?

Je maakt een slechte grap over de vorige man die je zo versleept hebt en hoe 
goed die [klus](klus/geld-verdienen.md) betaalde.

Je zegt dat je even moet [plassen](plassen/watnu.md), en je loopt richting de bosjes.