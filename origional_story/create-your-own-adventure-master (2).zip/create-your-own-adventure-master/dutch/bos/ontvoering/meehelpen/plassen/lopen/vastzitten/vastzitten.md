Aan het eind van de heubel val je beneden, maar een van je handen komt klem te
zitten aan de rand.

Nu hang je daar, je benen zwengelen in de lucht. De enigste manier
om te zorgen dat je niet verder valt is door je mobiel te laten vallen in de
hand die klem zit.

Wat doe je?
