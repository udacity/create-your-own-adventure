Je doet net alsof je plast, maar een van de zware jongens vertrouwt het niet.
Hij komt op je aflopen. Wat doe je?