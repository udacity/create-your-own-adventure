Je drukt 112 in op je mobiel maar de toetsen maken geluid en de zware jongens horen het.
Wat doe je?