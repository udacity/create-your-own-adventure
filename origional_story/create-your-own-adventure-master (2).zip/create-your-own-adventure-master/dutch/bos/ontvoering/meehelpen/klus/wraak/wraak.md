Beide mannen slaan stijf achterover van verbazing, hoe is het mogelijk! 

"Lucien was toch vergiftigd door Mafkees Mark....
de nieuwste leerling van onze baas?" vraagt de dikste man. 

"Dan is die verdomde Mark toch de mol!" schreeuwt de langste man
kokend van woede, wetende dat zijn laatste minuten zijn geteld.

Hij is nog niet uitgepraat...
of razendsnel pak ik met beide handen van onder mijn trui twee vlijmscherpe werpmessen.

En met een soepele werpbeweging gooi ik ze richting de hoofden van de verschikte mannen...