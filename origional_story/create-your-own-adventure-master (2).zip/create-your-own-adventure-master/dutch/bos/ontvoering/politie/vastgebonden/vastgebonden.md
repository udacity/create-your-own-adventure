De mannen laten dit natuurlijk niet zomaar op zich zitten en komen dreigend op je af.

Voordat je om hulp hebt kunnen roepen, hebben ze je al beetgepakt. 

Ze plakken je mond af met een stuk tape, en binden je armen achter je rug.

"Je had je hier beter niet mee kunnen bemoeien!" sist de een.

En terwijl hij de lijkzak optilt, geeft de ander je een por. "Meekomen jij!"