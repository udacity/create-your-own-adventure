Het is al donker als je wakker wordt in een schuur.

Je hoofd doet pijn, je ligt op de grond en je armen zijn achter je rug vastgebonden.

Je probeert op te staan.