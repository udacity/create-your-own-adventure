Eenmaal in verbinding met de hulpdiensen, vertel je je locatie.

Je legt het probleem uit en de politie is meteen onderweg.
Eind goed al goed!

Of toch niet...

De mannen [komen dreigend op je af](vastgebonden/vastgebonden.md)

Je hoort een doffe klap en je [verliest het bewustzijn](schuur/schuur.md)