Ondanks de kater, heb je door de adrenaline even een helder moment.
Je staat er bij stil dat je telefoon niet in stille modus staat.
Voorzichtig haal je je telefoon uit je broekzak om hem te muten.

Terwijl je toekijkt hoe de mannen een gat graven krijg je last van je knieën.
Voorzichtig probeer je in een andere pose te zitten, maar door het geritsel
van de struiken trek je de aandacht van de mannen.

Je besluit terug naar [de hei](../../welkom.md) te rennen.

Je besluit te huilen om je moeder terwijl de mannen je afmaken.

De mannen besluiten je te [ontvoeren](AllesKomtGoed/alleskomtgoed.md).

Je besluit de [politie te bellen](politie/politie.md).

Je besluit de mannen [mee te helpen](meehelpen/meehelpen.md) :-).