[Chorus]
'Cause baby you look happier, you do
My friends told me one day I'll feel it too
And until then I'll smile to hide the truth
But I know I was happier with you