[Chorus]
Baby, I'm dancing in the dark with you between my arms
Barefoot on the grass, listening to our favourite song
When you said you looked a mess, I whispered underneath my breath
But you heard it, darling, you look perfect tonight