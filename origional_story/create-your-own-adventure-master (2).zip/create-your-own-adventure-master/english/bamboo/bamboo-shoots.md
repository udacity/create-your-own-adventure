at the top of the bamboo trees you meet a whole panda family, they are friendly.
they show you a path ahead out of the forest, which you take. As you venture deep into the forest
you start to realize these pandas may not be as friendly as you thought.

You turn around and the pandas all have evil grins.  They climb down from the
bamboo and walk towards you.

You don't know what to do.The pandas continue to walk towards you.

You begin retreating slowly.Suddenly,one of the pandas speed up.

You saw Panda coming more closer to you!

You saw Panda and it is really big!

How strong is scaffolding made of bamboo you ask?

Well, not so sure. But you have no other choice to take a bamboo as a weapon against the evil pandas.