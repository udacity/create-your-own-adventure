You decide to jump.  Several steps back, running start, push off 
with perfect timing.  Your are in the air.  The fissure is a 
gaping mouth beneath you, hungry.  You land on the far side, 
just. Gasping, adrenalized, you look backjust in time to see 
the earth you were standing on moments ago crumble and fall 
into nothing. You turn and begin to run.  Looking down at 
your feet, you realize the ground beneath you is also cracking.
Running faster now.  Something is ahead of you, a cubical rock
protrudes from the ground, it's top edge head high.  You 
scramble to the top just in time to see the rest of the 
solid ground surrounding you fall into emptiness.  
Everything stops shaking.  You are standing on a piller
whose connection to the ground is impercievable.  
All around you is open air.  You are stranded.  
At least it's not dark anymore...
