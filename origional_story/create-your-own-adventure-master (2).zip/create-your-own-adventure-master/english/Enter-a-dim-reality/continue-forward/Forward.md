After a moment of deliberation, you realize that going 
back would not be good for your sanity.  You continue to run.... 
Finally, you reach the source of the light.  You are 
standing on the edge of a small body of water, in the 
middle, hovering just above the surface, is a quivering
orb of light.  You feel drawn to it. 

Do you [jump in and swim to the orb?](Forward_Swim/forwardSwim.md)

or do you [stay on the shore?](Forward_Stay/forwardStay.md)
