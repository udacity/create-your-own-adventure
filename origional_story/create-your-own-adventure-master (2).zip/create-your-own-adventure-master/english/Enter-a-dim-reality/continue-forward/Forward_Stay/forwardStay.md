You stay on the bank, unsure of what trouble might await you in the water.
You sit down, mesmerized by the light.  It begins to fade - you begin to panic.  
The light is gone, you scan the horizon frantically, desperately hoping to see
the another beacon somewhere in the darkness.  Nothing...

It is pitch black. You are likely to be eaten by a [grue](../../../grue/grue.md).
