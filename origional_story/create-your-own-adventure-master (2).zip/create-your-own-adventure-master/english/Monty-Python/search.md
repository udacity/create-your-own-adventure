You set out on a search for the holy grail.

[Look for Grue](../grue/grue.md)

Ride to the nearest castle.

Meet the black knight

Chop off his limbs

[It's only a flesh wound!](https://www.youtube.com/watch?v=zKhEw7nD9C4)

[Run into the Knights who say "Ni!"](https://www.youtube.com/watch?v=zIV4poUZAQo)

Go off to find a nice shrubbery

[Run into the Knights who say "Ni!" again!](https://www.youtube.com/watch?v=zIV4poUZAQo)
