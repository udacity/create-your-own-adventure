#What the Cat Said

You ask your cat if she might be willing to finish writing your symphony
for you. "It's nearly halfway done!" you tell her. "I'll split the profits
with you!"

Too late you realize that cats have no concept of fame or fiscal gain, and
that they have no particular musicality. Your cat reaches out a paw and
knocks over the cup of coffee you so foolishly set on the table next to
the only copy of your work. The ink you used was exceptionally poor and
immediately runs.

Your symphony is ruined.

Your cat doesn't care.

[Take this as a sign to change careers.](../change-of-career/career.md)

[Give the cat to your sister and become a dog person.](../dog-person/dog.md)

[Eh, it wasn't that great a symphony anyway. Settle in for kitty cuddles](../cuddle-the-cat/cuddle-cat.md)

[Say "Oh, kitty.  I love you, but you do cause trouble.](../cat-symphony-trouble/rewrite-symphony.md)


