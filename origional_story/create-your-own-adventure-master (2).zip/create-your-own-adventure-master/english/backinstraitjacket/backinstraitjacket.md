Having put back on the straitjacket, your prior dread slips away
and you experience a deep sense of peace, safe in the knowledge
that this is simply a figment of your deeply delusional
imagination.

Ten minutes later, you hear but do not see someone reminding
you to take all of our medication.

[Do you take your meds?](takemeds/takemeds.md)