Are you craze?
You can't take your meds. You're in a straightjacket.