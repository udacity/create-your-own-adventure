Bayes' Theorem: P(A|B) = P(B|A)P(A)/P(B)

I learnt Bayes Theorem long back but i forgot

[Daddy, but where do priors come from](priors/priors.md)?

[Daddy, can I have a glass of water](../coffee/drink-water/drink.md)?

[Daddy, are there priors in my chocolate](../chocolateOrSleep/chocolateOrSleep.md)?
