And they say, �There is not but our worldly life; 
we die and live (i.e. some people die and others live,
replacing them) and nothing destroys us except time.� 
And they have of that no knowledge; they are only assuming. 
And when Our verses are recited to them as clear evidences,
their argument is only that they say, �Bring [back] our forefathers, 
if you should be truthful.� Say, �God causes you to live, 
then causes you to die; then He will assemble you for the Day of Resurrection, 
about which there is no doubt,� but most of the people do not know.