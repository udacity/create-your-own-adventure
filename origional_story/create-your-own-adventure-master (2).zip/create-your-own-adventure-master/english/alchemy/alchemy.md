You take off your backpack and pull out your trusty acetylene torch. You place the first
marshmallow in a crucible and apply the flame. Chanting an incantation that has been
passed down through generations of alchemists, you stare into the glowing crucible as the
marshmallow melts into a cauldron of orange flame. As the fiery light coalesces into the
shape of a coin at the bottom of the crucible, you turn off the flame. You remove a 
mysterious small wooden box from your backpack, open it, and remove a ceramic coin mold
from inside. After placing the mold in front of your feet, you carefully pour the molten
metal into the mold.

Time passes, and the coin solidifies as it cools.

You gain 1 gold coin.

You decide to play it safe and repeat the process a few times. Who knows how many coins
the high-score currently is or how many you will need on your adventure?

The creation process gets quicker and quicker each time you practice the ancient art of
alchemy. Your skills improve. However, on the fifth run, the coin has an air anomaly
in its centre.

You hold the malformed coin up to to light and study it moving backwards and
forwards - studying its imperfection - a ring like shape.

Looking through the hole, the air shimmers, giving the other side a
hazy appearance.
The objects on the other side appear to be vacillating, as if they were
breathing.

You slip the ring over your finger and ...

[A polar bear suddenly appears and charges towards you](../polar-bear-attack/polar-bear-attack.md)

[you close you eyes and recite Buzz Lightyear's "To infinity and beyond!"](../my-story/my-story.md)

[quickly decide to take the ring off and try using its unknown powers later](../android-v6/use-android-v6.md)

[Congratulations!](../marshmallow.md)

[Transform!](../transform/transform.md)

[You teleport to the Incantation Forrest](../incantation-forrest/incantation-forrest.md)

and puff! you turn into a blob fish while only a few feet remain between you 
and the polar bear...
and the rein deer......
