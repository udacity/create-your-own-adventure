There is a very successful story called DKER !

Could you guess what's all about?