I finally understand git and gitHub. I actually understand branches and merges.

What am I going to do with my new found knowledge?  
The world is now my [oyster.](https://en.wikipedia.org/wiki/Pacific_oyster)

Have some booyah stew
or call a [spirit](../call-spirit/call-spirit.md)