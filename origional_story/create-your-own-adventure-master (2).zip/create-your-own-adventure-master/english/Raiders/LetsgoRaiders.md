Lets go Raiders!

[Here's the link](https://www.google.com)

You see Batman at the Raiders game you are attending and you decide
to go ask him some personal questions. [This is what you find](
/batman/batman.md)!