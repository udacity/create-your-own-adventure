The sun on your face is the first thing you become aware of and you instinctively put your hand up to shield your eyes
from the brightness. You're still in your clothes and are lying in the middle of a bed in what looks to be some sort of
cheap motel room. You have no idea where you are or how you got here.

You sit up and immediately feel pain on the back of your head. Some dried blood cakes the pillow you were lying on. Your
wallet and mobile phone are gone. In fact, your pockets are completely empty.

[Explore the motel room.](explore-room/room.md)

[Go outside.](explore-outside/outside.md)