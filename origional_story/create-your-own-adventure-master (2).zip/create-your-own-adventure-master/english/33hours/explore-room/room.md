You're not really sure what you're looking for, but search the room frantically to find out where you are and why you
are here. The nightstand is completely empty. There's not even a phonebook.

[Try the phone.](use-phone/use-phone.md)

[Look under the bed.](look-under-bed/look-under-bed.md)

[Look under the carpet on the floor.](under-carpet/under-carpet.md)
