You pick up the phone and start to dial, but stop when you hear a strange high-pitched hum. You press the receiver
button several times, but the hum will not go away. You try dialing a number, but nothing happens. At one point you
hear a crackle and then what sounds like faint voices, but then the hum continues until you give up and put the 
phone down.

[Look under bed.](../look-under-bed/look-under-bed.md)

[Go outside.](../../explore-outside/outside.md)