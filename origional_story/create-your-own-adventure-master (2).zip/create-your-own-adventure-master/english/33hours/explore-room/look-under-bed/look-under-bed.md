You look under the bed and find nothing. It's like this entire motel room has been sanitized of every possible
detail or clue that might help you figure out what's going on.

[Try the phone.](../use-phone/use-phone.md)

[Go outside.](../../explore-outside/outside.md)