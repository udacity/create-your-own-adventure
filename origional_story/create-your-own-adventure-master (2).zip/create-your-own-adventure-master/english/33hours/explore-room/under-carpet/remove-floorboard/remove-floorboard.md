You pry at the loose floorboard and manage to get a grip on it.

You pull the floorboard out and see an old cigar box hidden below it.

[Put floorboard and carpet back](../../room.md)