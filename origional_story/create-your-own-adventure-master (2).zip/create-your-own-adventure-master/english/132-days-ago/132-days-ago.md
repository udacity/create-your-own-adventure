132 days ago you went to Tesco to buy marshmallow
but end up buying chocolate because you had not enough money to buy marshmallow.
or a pack of four donuts.

You decide to [eat the chocolate anyway.](../youre-fine/youre-fine.md)

Or, you could [eat a juicy steak](../rib-eye/rib-eye.md)

Maybe even a [fart] (../eat-farts/eat-farts.md)or two?

sick of it