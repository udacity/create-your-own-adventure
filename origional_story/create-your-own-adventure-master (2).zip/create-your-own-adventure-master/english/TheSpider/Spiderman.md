You were scared, unable to move as your skin starts to burn!

The spider bit you.

That night you lay restless, trying to sleep. 

You wake up the next day; strong and fast, what do you do?

[Save the world](save-world/victory.md)

[Do your homework](do-homework/study.md)