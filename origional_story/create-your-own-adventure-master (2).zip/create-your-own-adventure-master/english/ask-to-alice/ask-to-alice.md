She say to you that you need to talk with hookah smoking caterpillar because he has
all your answers.

But how can you believe anyone who stands 10 ft tall holding a white rabbit? What is that 
[music](https://www.youtube.com/watch?v=WANNqr-vcx0) that you're hearing?  You decide to that 
it's time for another pill, but which one should you take?

Pick one of the choices below:

Just click on the link.

[The one that makes you larger](../super-man/save-the-word.md)

[The one that makes you sleep](../sleep/marshmallow.md)

[The one that your mother gave you that doesn't do anything](./ask-to-alice.md)

[The one with a transparent glowing scarab within it](../scarab/goddess.md)

[The one that makes you chill out](../sleep/sit-down-to-meditate/sit-down-to-meditate.md)

[The one that lets you speak Nintendo](../../japanese/beer/beer.md)
