[But everything changed when the firenation attacked...](https://www.youtube.com/watch?v=pJUgCzEdx9k)

[Fire Lord Ozai](http://avatar.wikia.com/wiki/Ozai) wanted to conquer the other nations and rule the world.

[Aang the last air bender](http://avatar.wikia.com/wiki/Aang) But there was one who stood in his way.

The next step is other planets.



You feel stranded.
How can I get off of this planet?
You are desperate and scream, "Oh God!"
You are surrounded by a horde of creatures that look like sharks with legs.
Suddenly - [you wake up!](../wake-up/wake-up.md)
