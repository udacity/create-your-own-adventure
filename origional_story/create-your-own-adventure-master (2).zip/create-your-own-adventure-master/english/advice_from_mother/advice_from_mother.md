You remember that your mother always told you that magical creatures 
such as yourself should avoid LSD. Knowing now that this is all a bad 
trip, you use the bonfire to melt all the marshmallows, ignoring the 
giant pile of fluff in one corner, watching the swirl and glitter of 
the toasting surface until you can walk out of the corner and back 
into the bar.

just a random test

My mother also told me that I should eat my vegetables.
Something about them being good for me. 
But at that time, I was at the age that I thought "If it doesn't taste good, it just can't be good for me".

"[She answers.](../bear-story/bear-story.md)"
