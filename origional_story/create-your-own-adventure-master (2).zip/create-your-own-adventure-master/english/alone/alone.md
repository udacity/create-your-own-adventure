Alone

Chapter 1:

Kristy wakes up to the strange sounds from the walls of her dorm.

She gets off the bed and carefully look around for anything suspicious.

She senses a movement along the wall on the other side of the dorm room.

She sneaks next to the wall and tries to hear anyone on the other side of the wall.

She hears someone gasping heavily and trembles in fear.

Kristy gets drenched in sweat and sits on the edge
of her bed gulping a bottle of water.

Kristy hears someone approaching her room. She sneaks 
beneath the bed and shuts her mouth to mute her 
anxiety.

A stranger in jeans and hoodie, covering larger portion of his
face with his hood walks into the room and looks around.

He walks across the room and scans the surroundings and
hide in the walk-in closet.

Kristy locks the closet from outside and screams on top of her voice.

Everyone in the dorm rushes to Kristy's room and her friends alert
the security. Security storms into the room and carefully opens the
closet door.

Security checks inside and finds no one. Kristy scatters everything in the closet
and finds nothing. Everyones leaves cursing Kristy and they think that it's a prank.

Kristy collapses and weeps uncontrollably. 

Kristy's friends Bella and Ana console her and checks her surroundings.

They find no one around, everything in Kristy's room is untouched. Stranger
sneaks behind the window and watch her weep.

Kristy sees him at the window and runs into it. Her nose bleeds with the impact and 
stranger fades into the dark leaving no clue.

Bella holds Kristy from behind and usher her to the bed and Ana locks the window.
Bella grabs the first aid kit and treats Kristy.

Bella stops the blood flow and plasters Kristy's nose and Ana scans surroundings
to check for anything suspicious.

Kristy eventually crashes on her bed but the stranger come back to strangle her
with pillow.

Kristy protests and grabs the lamp next to her bed and hit him on his head.
Stranger's head starts bleeding and he run away from her room.

Kristy screams again but no one bothers to check on her.


Kristy sobs in despair but gets a nasty idea to smoke him out. She sets her room on 
fire.

And the screams continues to come again and again

Bella sprint to Kristy's room and finds her getting terrified seeing herself
in the mirror.

Bella records it with her phone and shivers seeing Kristy.

Bella sees Kristy seeing herself in the mirror and tremble.

Bella ushers Kristy on to her bed and calm her down.

Bella palms her head while Kristy gets normalized.

Stranger smirks seeing Kristy and escape into the dark.

End of Chapter 1.

--------------------------------

Chapter 2:

One month ago....

It was like a usual Saturday night for Kristy. She was lonely and wished that she had any friends at all...