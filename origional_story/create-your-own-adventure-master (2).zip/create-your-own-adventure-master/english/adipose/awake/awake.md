The answer was neither, you are actually the
universe itself. What an unfortunate lonely 
existance. Doomed to look into yourself for unending 
eternity. The dream you just had is the closest 
thing you can do to feeling and only happens when 
peer into the center of a star. The burning 
sensation you felt was the star burning your cosmic 
retna. Unfortunitely there is no way to tell if it 
will be a pleasent dream or a hellish nightmare, but 
anything is better then your eternal loneliness, so 
you move on to the white dwarf two parsecs over. Then,
you died in your dreams.

Just adding a line this time.

Adding another line.