The scene opens with an unshaven man in his bathrobe.  
He lounges on his couch next to a mostly-empty pizza box.  
The phone rings; he answers but we only hear his side of the conversation...

"Hey."

"Yeah, but you know I'm really kinda busy right now."

"How many?  But shouldn't kids really be in school right now?"

"I think there are supposed to be fire extinguishers ON the bus - couldn't they use that?"

"What if they just all move to the end of the bus that's NOT over the cliff?"

"OK, OK, just let me call for an Uber..."

