Epic DC

Once upon a time DC Comics made an EPIC vigilante who simple changes his voice to disguise. 

Give it a deep thouht and figure it out. 

Hint: A useless character :)

[Green Arrow](Arrow/arrow.md)

[Melancholic Man](Man/melancholic.md)
