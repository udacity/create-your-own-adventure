Rupinderpal is Indian Hockey player 
To know more about him click [here](https://en.wikipedia.org/wiki/Rupinder_Pal_Singh)


[twitter profile](https://twitter.com/rupinderbob3?lang=en)


[instagram profile](https://www.instagram.com/rupinderbob3/)