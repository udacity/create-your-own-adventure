“Know that the life of this world is only play and amusement, 
pomp and mutual boasting among you, and rivalry in respect of 
wealth and children, as the likeness of vegetation after rain,
thereof the growth is pleasing to the tiller; afterwards it 
dries up and you see it turning yellow; then it becomes straw1.
But in the Hereafter (there is) a severe torment (for the 
disbelievers, evil-doers), and (there is) Forgiveness from 
Allah and (His) Good Pleasure (for the believers, good-doers),
whereas the life of this world is only a deceiving enjoyment“.
[QURAN 57:20]

"Life isn't that simple but you got to take every possible risk in life to achieve something."

"Explore another dimension[dimension](../dimensions/dimension.md). It's fun"
