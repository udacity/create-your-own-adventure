When it is time, it will be time. 

But is it time yet? [How will we know?](http://www.campingdude.com/content/skit/is_it_time_yet-101.asp)
when it will be thunderous all around, when there is a lightning in the sky.
when the earth is shaking. Yes, it is the indiacation of our [time](http://chitrasoundar.com/kids/?p=601).