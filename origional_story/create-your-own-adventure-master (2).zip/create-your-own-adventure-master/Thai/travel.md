It is amazingly beautiful.
We have plenty of stunning beaches and crystal clear water.
Imagine you are at the sea now, what would you like to do?

What do you want to do?

[Just have a chocolate while stroll on the beach](../english/chocolateOrSleep/chocolateOrSleep.md)
 
 [Have Tom Yum Kung. The food is as spicy as the weather.](Cuisine/TomYumKung.md)

 I want to sleep on a beach and dream of [hiking](Activities/Hiking.md) a mountain in the Northern of Thailand.