Shkoni tek stacioni i trenit nje ore para ores se nisjes.

Eshte stacioni i trenit ne Rome?

Apo eshte ne Paris?

Apo eshte Penn Station, New York?

Apo ndonje stacion tjeter?
