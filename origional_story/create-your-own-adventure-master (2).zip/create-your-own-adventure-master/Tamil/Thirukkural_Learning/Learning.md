﻿திருக்குறள்
===============================================================================

அதிகாரம்/Chapter: கடவுள் வாழ்த்து/ Prayer to God

குறள் 1:
அகர முதல எழுத்தெல்லாம் ஆதி
பகவன் முதற்றே உலகு

All the letters are voiced subsequent to the letter "A" and hence we call them as alphabets.
For the world that came to existence there is One Who stood 
before beginningless (and stands endless).
That God is the ultimate Precedent of the world.


குறள் 2:
கற்றதனால் ஆய பயனென்கொல் வாலறிவன்
நற்றாள் தொழாஅர் எனின்

No fruit have men of all their studied lore,
Save they the 'Purely Wise One's' feet adore

===============================================================================

பால்: பொருட்பால்
அதிகாரம்/Chapter: கல்வி / Learning 

குறள் 391:
கற்க கசடறக் கற்பவை கற்றபின்
நிற்க அதற்குத் தக.

Let a man learn thoroughly whatever he may learn, and let his conduct be worthy
of his learning.

குறள் 392:
எண்ணென்ப ஏனை எழுத்தென்ப இவ்விரண்டும்
கண்ணென்ப வாழும் உயிர்க்கு.

Letters and numbers are the two eyes of man.

குறள் 393:
கண்ணுடையர் என்பவர் கற்றோர் முகத்திரண்டு
புண்ணுடையர் கல்லா தவர்.

The learned are said to have eyes, but the unlearned have (merely) two sores 
in their face.

குறள் 394:
உவப்பத் தலைக்கூடி உள்ளப் பிரிதல்
அனைத்தே புலவர் தொழில்.

It is the part of the learned to give joy to those whom they meet, and on 
leaving, to make them think (Oh! when shall we meet them again).

