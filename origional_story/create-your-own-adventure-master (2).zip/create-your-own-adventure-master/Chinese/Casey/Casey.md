Casey现在为udacity工作，自动合并GitHub的pull request。
Casey is a help bot.
Casey won't accept a pull request that a fix typo.