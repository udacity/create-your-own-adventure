The Little Prince is a play based on the book of the same name by Antoine de Saint-Exupéry, 

adapted by Rick Cummins and John Scoullar before 2000. 

Rick Cummins wrote the music, and John Scoullar wrote the script and lyrics. 
