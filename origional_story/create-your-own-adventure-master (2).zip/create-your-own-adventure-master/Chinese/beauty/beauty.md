木心老爷子说过，[美貌](https://www.douban.com/group/topic/12641976/)是一种表情。^_^

性感是一种邀请。