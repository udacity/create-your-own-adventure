大家好，我叫Andy chen,这是我的豆瓣个人网址，里面有我感兴趣的电影、书籍、和音乐，当然也有我写的文章，如果你感兴趣，
feel free to check it out and add me as friend, 谢谢！

点击这里[here](https://www.douban.com/people/3279743/)访问我的主页。