0。因为香瓜不长树上。
[下一个](../carowner/car.md)
