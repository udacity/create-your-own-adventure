In a small town where everyone knows everyone,
a peculiar incident starts a chain of events,
that leads to the disappearance of a child,
which begins to tear at thefabric of an otherwise peaceful community. 
Dark government agencies and seemingly malevolent supernatural forces converge on the town,
while a few locals begin to understand that,
there's more going on than meets the eye.
Question: which TV series are they?