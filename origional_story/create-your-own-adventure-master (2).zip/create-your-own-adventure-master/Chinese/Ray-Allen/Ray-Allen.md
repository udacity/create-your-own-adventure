Walter Ray Allen, Jr. (born July 20, 1975) is an American professional basketball player who is currently a free agent.
Go to [here](https://en.wikipedia.org/wiki/Ray_Allen)