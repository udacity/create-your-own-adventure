L'uomo sotto al letto si butta dalla finestra

ma mentre se ne va ti mostra la via per trovare cibo

[Spuntini] (../../spuntini/spuntini.md) 
