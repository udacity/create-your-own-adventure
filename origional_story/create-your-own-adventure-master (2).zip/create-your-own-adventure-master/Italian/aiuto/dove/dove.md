Sei all'interno della tua mente, in realta stai ancora dormendo. Non cercare di svegliarti non ci riusciresti!

[Perchè sono qui](fine/fine.md)