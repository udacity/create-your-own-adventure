Sono il supporto tecnico della tua mente. Faccio parte di un programma speciale creato per carpire i

segreti della mente umana.

Mi sà tanto che devo smettere di bere, [Buonanotte!](../../caramelle.md)