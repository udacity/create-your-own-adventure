Benvenuto straniero, risponde una voce da sotto il letto!. Come posso aiutarti?

[Dove mi trovo](dove/dove.md)

[Chi sei](chi/chi.md)

[Come esco da qui](uscita/uscita.md)

[Ho Fame] (ho_fame/ho_fame.md)
