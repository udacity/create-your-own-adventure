Giri le fotografie e dietro ad una trovi uno 
strano messaggio in parte cancellato dal tempo.

La fotografia ritrae una famiglia numerosa.
Tutti i volti sono ben visibili ad eccezione di quello 
di una giovane ragazza che è stato bruciato.

Il messaggio dietro la fotografia è il seguente: 
"Sei sulla buona strada..."

Giri nuovamente la fotografia e la guardi meglio.
