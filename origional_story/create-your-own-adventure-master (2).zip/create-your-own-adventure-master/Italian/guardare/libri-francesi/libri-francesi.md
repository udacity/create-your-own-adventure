A una prima occhiata i libri sembrano essere lì da molto tempo: la polvere che li ricopre rende difficile leggerne il
titolo alla tenue luce al neon che illumina la stanza.

I volumi sono sistemati con ordine maniacale, in rigoroso ordine alfabetico.

Muovendo gli occhi lungo i diversi scaffali, incontri un libro stranamente non ricoperto di polvere, come se fosse
stato letto da poco: "Les histoires horribles d'enfants chauves-souris", che suona qualcosa come "Le terribili storie
dei bambini pipistrello".

[Lasci perdere i libri e decidi di esaminare le fotografie](../vecchie-fotografie/vecchie-fotografie.md)

[Prendi il libro](./prendere-il-libro/prendere-il-libro.md)

[Hai fame... Colazione](colazione/colazione.md)
