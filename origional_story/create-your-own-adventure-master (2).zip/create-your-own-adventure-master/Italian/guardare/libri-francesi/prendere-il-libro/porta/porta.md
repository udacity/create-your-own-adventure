Con cautela apri lentamente la porta, e restando sulla soglia cerchi di vedere
qualcosa nell'oscurita'.  La luce proveniente dalla stanza e' appena sufficiente
ad illuminare degli scalini di pietra che discendono chissa' dove. Un lontano
rumore di macchinari di qualche tipo si sente in distanza.

Decidi sia meglio trovare una torcia elettrica o una candela prima
d'avventurarsi.

[Chiudi la porta e torni ad osservare la stanza](../../libri-francesi.md)

[Cerchi una torcia elettrica] (cerchi-torcia/cerchi-torcia.md)
