Non trovi di meglio che una vecchia candela in un cassetto, ma niente con cui accenderla.
