Allunghi una mano per afferrare il libro misterioso e con un movimento deciso lo estrai dalla libreria.

Ma ecco che un rumore proveniente dall'altro lato della stanza ti fa girare di scatto, 
lasciando cadere il libro.

Là, dove prima si trovava una solida parete, adesso è comparsa un'ampia porta, già socchiusa, 
che non lascia intravedere niente se non una fitta oscurità.

[Torno a dormire](../../../domire/sogno-strano.md)

[Apro la finestra](../../../finestra/apri.md)

[Apro la porta](porta/porta.md)
