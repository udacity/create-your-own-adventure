Decidi dunque di scoprire da dove possa provenire quel profumino

che ti ha fatto ricordare che è ora di colazione
