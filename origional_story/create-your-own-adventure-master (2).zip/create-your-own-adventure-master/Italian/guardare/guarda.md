Le pareti si restringono e dei simpatici e piccoli elfi ballano e cantano...
i funghi "speciali" che ho mangiato ieri in realtà erano allucinogeni.

Non avresti dovuto fidarti di quella ragazza conosciuta alla festa.

Hai pochi, confusi ricordi di quello che è successo. Con la testa che gira per l'intossicazione, provi ad alzarti.
Le gambe ti reggono a malapena e, in pochi difficili passi, riesci a raggiungere la libreria che sta di fronte al letto.

Sugli scaffali trovi solo vecchi libri di leggende francesi e alcune fotografie sbiadite.

[Esamini le fotografie, sperando di riconoscere qualcuno](vecchie-fotografie/vecchie-fotografie.md)

[Sfogli i libri, in cerca di qualche indizio](libri-francesi/libri-francesi.md)

[Ti manca l'aria, apri la finestra](../finestra/apri.md)
