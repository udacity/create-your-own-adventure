Una mattina, ti svegli in una strana stanza.
Che fai?

[Torno a dormire](domire/sogno-strano.md)

[Cerco l'uscita](scappare/cercare-uscita.md)

[Apro la finestra](finestra/apri.md)

[Mi guardo intorno](guardare/guarda.md)

[Mi conto le dita per vedere se sono veramente sveglio](verifica/verifica.md)

[Cerco aiuto ulrando c'è qualcuno?](aiuto/aiuto.md)

[Cerco qualcosa per fare colazione](colazione/colazione.md)

[Spuntini] (spuntini/spuntini.md)

[Alice non abita più qui] (alice/alice.md)

[Cerco un computer] (giocare/computer.md)

[Passeggiare] (passeggiare/passeggiare.md)

[Salgo in macchina] (ascoltare/profumato.md)

[Telefono ad Antonio Conte](antonio_conte/antonio.md)

[Lavorare](lavorare/lavorare.md)

[Accendo la luce](luce/luce.md)

[Cerco lo smartphone] (smartphone/smartphone.md)

[Canto](canto/canto.md)

[Guardo l'orologio](orologio/orologio.md)
