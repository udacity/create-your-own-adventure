Frugo nelle tasche e trovo il mio telefono.
Ma � stranamente elastico e risponde al tocco molto a modo suo.
Cerco disperatamente di accedere al GPS ma non ottengo nessuna risposta.
Allora vince il riflesso condizionato e penso a quale social mi potrebbe essere pi� utile nell'occasione.

Scelgo [Facebook](facebook/facebook.md)

Scelgo [Instagram](instagram/instagram.md)