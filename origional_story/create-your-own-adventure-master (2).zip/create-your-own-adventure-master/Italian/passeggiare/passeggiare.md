Vado molto di fretta,
penso di prendere l'auto,
poi comincio a cammirare avvicinandomi al garage,
lo sorpasso, continuo a camminare, non mi fermo più.
Che bella passeggiata.
