Mentre ti volti verso la parete opposta, che ospita una libreria piena di volumi antichi, 
noti con inquietudine che la stanza è priva di finestre.
Non c'è traccia di porte: la consapevolezza di essere in trappola si fa strada nei tuoi pensieri.

[Rovesci tutti i libri cercando un passaggio segreto](cerca-passaggio/cerca-passaggio.md)
