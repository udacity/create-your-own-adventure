I fogli sono tutti bianchi.
Mentre osservi la scrivania noti un cassetto. 
Curiosamente, al posto della maniglia è presente solo un intaglio di forma triangolare.

[Inserisci l'oggetto triangolare nella fessura del cassetto](apri-cassetto/apri-cassetto.md)