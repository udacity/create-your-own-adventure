Fra i vetri rotti scopri un piccolo oggetto di forma triangolare, sembra
anch'esso essere fatto di vetro. Ti avvicini e noti che all'interno c'e'
una sfera dorata che emana una luce soffusa e pulsante.

[Ti guardi intorno e cerchi di capire dove ti trovi](esamina-stanza/esamina-stanza.md)
