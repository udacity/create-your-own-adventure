Vedendo quel casino, decidi di cercare una scopa per pulire e rimandi la fuga.
