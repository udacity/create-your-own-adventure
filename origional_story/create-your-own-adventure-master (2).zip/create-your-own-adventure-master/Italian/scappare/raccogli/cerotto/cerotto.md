Ti guardi in giro per cercare un cerotto, dovrebbe essercene uno nel cassetto.
Poi ti ricordi che non sei nella tua stanza.

[Scegli un'altra opzione] (../raccogli.md)
