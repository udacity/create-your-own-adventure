Raccogli i pezzi di vetro, ma ti ferisci una mano.

[Cerchi un cerotto] (cerotto/cerotto.md)

[Stringi i denti e resisti al dolore] (resisti/resisti.md)

[Ti butti sul pavimento piangendo dal dolore] (piangi/piangi.md)

[Torni a dormire](../../caramelle.md)