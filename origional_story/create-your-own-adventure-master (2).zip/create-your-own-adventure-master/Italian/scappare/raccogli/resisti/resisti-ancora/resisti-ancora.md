Continui a resistere, mentre il sangue continua a scorrere. Senti che i sensi ti stanno
abbandonando, la vista si offusca. Cadi a terra e muori dissanguato.
L'ultima cosa che vedi è il soffitto della stanza che si espande a dismisura fino ad inghiottire tutto quanto.
