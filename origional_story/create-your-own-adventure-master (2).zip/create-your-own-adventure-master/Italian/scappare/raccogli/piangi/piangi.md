Ti butti sul pavimento e inizi a piangere in preda agli spasmi per il dolore.
Purtroppo nel farlo ti dimentichi che il pavimento è pieno di vetri rotti,
che ti provocano una serie di ferite gravi. Anzi, mortali.
