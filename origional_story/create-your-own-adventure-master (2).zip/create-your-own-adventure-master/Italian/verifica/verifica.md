Mi conto le dita, e la prima volta sono 12,
la seconda volta sono 7, la terza sono 4,
mi rendo conto che stao dormendo, ma per
la gioia di sapermi in un sogno, mi sveglio,
stavolta nella mia stanza.

