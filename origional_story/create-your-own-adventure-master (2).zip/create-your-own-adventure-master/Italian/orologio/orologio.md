Guardo l'orologio per capire se
è giorno o notte.
