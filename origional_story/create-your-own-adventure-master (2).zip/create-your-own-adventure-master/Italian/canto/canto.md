Sento improvvisamente una irrefrenabile voglia di cantare toto cutugno.
"Voglio andare a vivere in campagna,
sotto la rugiada che mi bagnaaaa"
