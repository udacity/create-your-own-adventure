
Ti appare un paesaggio fiabesco,

noti subito un tappeto volante che 

staziona ad una ventina di metri da te

e in lontananza sullo sfondo scorgi un gigantesco T-rex

Come reagisci?

[Prendi il telefono per fotografarlo](mangiato/mangiato.md)

[Crei una corda col lenzuolo e scendi dalla finestra](cadi/cadi.md)

[Torni a dormire](../caramelle.md)

[Crei una bambola voodoo per addomesticarlo](tour/tour.md)

[Attiri il tappeto] (attira-il-tappeto/attira-il-tappeto.md)
