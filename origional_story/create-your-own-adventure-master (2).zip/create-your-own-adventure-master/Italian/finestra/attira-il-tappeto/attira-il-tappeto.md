Chiami il tappeto per provare ad usarlo come mezzo di trasporto.
Il tappeto reagisce ai tuoi richiami ma non si avvicina a sufficienza per poterci salire.