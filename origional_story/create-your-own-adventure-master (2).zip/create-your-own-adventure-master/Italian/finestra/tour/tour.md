Con le tue tecniche di manipolazione mentale e la bambola voodoo riesci a domare il T-Rex, lo fai venire verso di te

Ci salti su e vai alla scoperta di questo mondo fiabesco in cui sei capitato
 