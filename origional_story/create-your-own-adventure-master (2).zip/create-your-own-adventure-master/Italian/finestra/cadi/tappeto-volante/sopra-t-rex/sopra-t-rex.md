Vedi il possente animale ruggire verso di te...

...quindi sorridi al lucertolone e viri col tappeto verso
il Marshmellow gigante, che si rivela una colazione molto piu gradita di te.
Il t-rex ti saluta mentre tu ti allontani verso una montagna che si staglia
all'orizzonte.
