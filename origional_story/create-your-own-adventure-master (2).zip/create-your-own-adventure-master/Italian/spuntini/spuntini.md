Vado alle macchinette
Non ho soldi sulla chiavetta
Torno a prendere soldi
Carico
Scelgo
Cade
Si ferma a meta'
Bestiemmio cordialmente
Torno alla postazione e scrivo questo