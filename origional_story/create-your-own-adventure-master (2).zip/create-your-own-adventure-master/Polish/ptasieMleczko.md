Pewnego ranka obudziłaś/eś się w dziwnym pokoju ze ścianami z ptaskiego mleczka.

Okazało się również, że masz na sobie niewygodną kurtkę i nie masz na sobie spodni...

Czujesz, że wzmaga się w tobie pragnienie, czy to nie jest dobry pomysł, żeby napić się Kadarki?

Co robisz? 

[Idziesz spac?](spanie/spaniee.md)

[Czujesz zew przygody](przygoda/przygoda.md)

[Chcesz się przebrać](ubranie/ubranie.md)

[Idziesz kupić Kadarkę](kadarka/kadarka.md)

