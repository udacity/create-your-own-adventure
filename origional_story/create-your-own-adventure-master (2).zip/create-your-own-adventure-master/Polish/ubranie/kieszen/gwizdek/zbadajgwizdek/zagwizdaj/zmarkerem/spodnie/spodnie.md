Niczym Picasso, zabierasz się do rysowania. Nie wiedzieć czemu, narysował-eś/aś 
spodnie Alladyna zrobione z tysiąca złotych cekinów! Co robisz ze spodniami?

[Spróbuj założyć](zalozyc/zalozyc.md)

[Przyjrzyj się spodniom](przyjrzyj/przyjrzyj.md)

[Podrzyj swój rysunek](podrzyj/podrzyj.md)


