Przyglądasz się spodniom z każdej strony próbując dostrzec coś interesującego.
Jedyne czego się dowiadujesz to, że żaden z Ciebie artysta ...

[Zastanow sie dalej co zrobic ze spodniami](../spodnie.md)
