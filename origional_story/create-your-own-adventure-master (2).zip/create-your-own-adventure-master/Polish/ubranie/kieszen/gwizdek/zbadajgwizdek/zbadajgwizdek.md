Obracasz rożowy, plastikowy gwizdek. Jest gładki, bardzo dobrze wykonany, nie widzisz jednak w nim nic szczegolnego.

[Postanawiasz zagwizdać jeszcze raz](zagwizdaj/zagwizdaj.md)

[Chowasz gwizdek z powrotem do kieszeni](gwizdekdokieszeni/gwizdekdokieszeni.md)
