Cała tablica pokryta jest Twoimi bazgrołami i szczerze mowiąc, nie przyniosło to żadnego efektu. Co dalej?

[Narysuj spodnie](../spodnie/spodnie.md)

[Narysuj zamek od kurtki](../zamek/zamek.md)

[Znowu nabazgraj byle co](../bazgroly/bazgroly.md)