Upuszczasz gwizdek na podłogę.Gwizdek leci nieubłaganie do ziemi, kiedy całe życie przewija ci się przed oczami
niczym pokaz slajdow.
Mimo że trwa to zaledwie ułamek sekundy masz wrażenie, że czas zwolnił i czekasz z przerażeniem na koniec lotu.
Kiedy gwizdek spotyka się z podłogą nie odbija się i nie wydaje żadnego dźwięku, jakby czas się zatrzymał.
