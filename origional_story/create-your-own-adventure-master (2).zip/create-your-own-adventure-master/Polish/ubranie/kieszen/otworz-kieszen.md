Otwierasz kieszen.
Okazuje sie byc bardzo gleboka. Na samym jej dnie znajdujesz maly, plastikowy gwizdek.  

[Dmuchnij w gwizdek](gwizdek/gwizdek.md)

[Wyrzuć gwizdek](wyrzucgwizdek/wyrzucgwizdek.md)
