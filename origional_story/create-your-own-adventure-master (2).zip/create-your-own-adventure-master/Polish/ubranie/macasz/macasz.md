Wyczuwasz coś dużego, nieregularnego i twardego.. Myślisz, że to niemożliwe, że to nie ma sensu...
Czy to... czy naprawdę... kalafior? A może brokuły? I wtedy wracają najgorsze wspomnienia z przedszkolnej stołówki.

[Kalafior](terrorysci/terrorysci.md)

[Brokuły](zupa/zupa.md)
