Wraz ze skunksem gotujecie kumpla na wolnym ogniu.
