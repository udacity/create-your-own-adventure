Po kąpieli w talerzu kumpla zupa nabiera zielonkawego koloru, a futro skunksa jest teraz wyraźnie czystsze.
