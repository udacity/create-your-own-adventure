Próbujesz ściągnąć swoją niewygodną kurtkę ale nie jest to proste.
Okazuje się, że po dotknięciu suwaka on znika.
Na jego miejscu pojawia się niespodziewanie mała kieszonka.
Ciekawe - myślisz.
Chyba warto sprawdzić co jest w środku.

[Otwierasz kieszen](kieszen/otworz-kieszen.md)

[Macasz kieszeń i próbujesz odgadnąć co jest w środku](macasz/macasz.md)



