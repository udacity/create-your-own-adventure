Spod łóżka wyciągasz AK47.
Korwin jest z Ciebie dumny, że masz taką broń i proponuje Ci wspólne poćwiczenie strzelania do tarczy przed domem.
