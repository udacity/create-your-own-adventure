Z szafki wyciągasz plakat z wizerunkiem Korwina i dajesz mu, żeby go podpisał swoim imieniem i nazwiskiem.
Niestety plakat nagle znika i ani Ty ani Korwin nie wiecie co właściwie się dzieje.
