Korwin jest wielce zadowolony z Twojego prezentu, dlatego
zabiera Cię na wspólne polowanie na czerwonych.

[Wyciągasz swoją broń](pistolet/pistolet.md)

[Przed wyjściem chcesz dostać autograf od Korwina](plakat/plakat.md)

[Proponujesz zamiast wspólnego polowania, objęcie władzy w Polsce](wladza/wladza.md)
