Proponujesz Korwinowi wyjazd do Nowego Jorku, gdzie spotkacie z Mariuszem Max Kolonko.
Tam opracujecie plan objęcia władzy w Polsce.
Korwin zgadza się, ale nie wiecie jak dostać się do Nowego Jorku.
