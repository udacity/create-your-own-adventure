To ja, Kelthuz. 
Zostajesz zaatakowany przez Kelthuza za to, że masz na sobie czerwoną koszulkę. 

Co robisz?

Bronisz się

Umierasz

[Jednak obrona](obrona/obrona.md)
