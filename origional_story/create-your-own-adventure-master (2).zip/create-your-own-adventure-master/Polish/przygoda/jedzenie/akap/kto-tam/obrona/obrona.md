Czym prędzej biegniesz to swojego biurka i chwytasz za klawiaturę, to Twoja ostatnia nadzieja, 
Twoje narzędzie obrony.

Atakujący postępuje w Twoją stronę, a Ty... co robisz?

Zmieniasz zdanie i chcesz schować się za biurkiem.

Atakujesz pierwszy?