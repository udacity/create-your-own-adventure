Umierasz.
