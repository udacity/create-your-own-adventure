Podchodzisz do drzwi i z ciekawością spoglądasz przez judasza by zobaczyć z kim masz do czynienia. 
Wydaje ci się ze znasz tego człowieka, lecz nie możesz sobie przypomnieć kto to. 

Jak myślisz, kto do ciebie zapukał?:

Czy może jest to sam [Rothbard] we własnej osobie?

A może gościsz samego [Siebie?]

Niemożliwe! czyżby osobiście zawitał do ciebie [Szumi?]

A więc mówisz, że widzisz [Kazimierę Szczukę?] 
