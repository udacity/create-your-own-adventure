Dzwonisz do wielkiej korporacji i mowisz ze masz miliony ton mleczka do sprzedazy.
W miedzyczasie namierzaja Twoj telefon, wysylaja ninje, ktory kroi Cie na male plasterki.
Korporacja przejmuje cale mleczko!