Stwierdzasz, że jesteś już najedzony. Z braku laku szczypiesz się w pośladek i budzisz w swoim własnym łóżku.
Zauwazasz jednak, ze wciaz masz na sobie owa niewygodna kurtke!
Stwierdzasz wiec, ze chcesz sie [przebrac](../../../ubranie/ubranie.md)