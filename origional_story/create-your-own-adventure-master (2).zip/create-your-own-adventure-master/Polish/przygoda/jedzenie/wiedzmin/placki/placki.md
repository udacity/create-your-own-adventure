Nie pytajac Cie o zdanie, nerd z nadludzka sila ciagnie Cie w strone ciemnego pomieszczenia.
Nie masz wiele czasu, a opcji niewiele. Co robisz??

najlepszą obroną jest atak - [rzucasz zaklecie IGNI](igni/igni.md)

najlepszą obroną jest... ucieczka - [teleportujesz sie do innej krainy](../../../../kadarka/kadarka.md)
