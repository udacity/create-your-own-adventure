Rzucasz zaklecie IGNI - z twoich rak strzelaja plomienie ognia, ktore kierujesz na nerda, 
przy okazji podpalajac meble stojace wzdluz sciany. 
Nerd wydaje okropny krzyk. Na jego twarzy pojawiaja sie nagle zmiany. Wydaje ci sie, ze on caly zmienia sie - 
jego cialo powoli rosnie i zmienia ksztalt. I nagle dociera to do ciebie - on nie jest czlowiekiem. 
To wampir, w dodatku z gatunku tych wyzszych...
Oj, zebys chociaz mial ze soba swoj srebrny miecz... 

Jak sie obronisz? 