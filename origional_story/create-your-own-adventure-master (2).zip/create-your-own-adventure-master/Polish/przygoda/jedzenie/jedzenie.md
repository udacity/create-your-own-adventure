Przez wiele godzin zajadasz się przepysznym ptasim mleczkiem. 
Jego cudowne właściwości odblokowują ukryty potencjał twojego umysłu. 
Twoje myśli błądzą pomiędzy ziemią a innymi planetami. 
Gdy całe ptasie mleczko jest już zjedzone, dochodzisz do oczywistych wniosków. Brzmią one:

[Może być z tego dobry biznes!](biznes/biznes.md)

[Korwin Krul!](korwin/korwin.md)

[Człowiek bez RiGCzu jest jak dżentelmen bez kapelusza, lub dama bez torebki](akap/akap.md)

[Jestem najedzony!](najedzony/najedzony.md)

[Mam ochotę zagrać w Wiedźmina trójkę](wiedzmin/wiedzmin.md)

[Chce mi się spać](spanie/spanie.md)

[Wyrosły mi skrzydła!](skrzydla/skrzydla.md)