Ściany ani drgną.

Co robisz?

[Rozbijasz ściany siłą mięśni](../miesnie/miesnie.md)

[Zaczynasz jeść ptasie mleczko](../jedzenie/jedzenie.md)

[Wypijasz eliksir woli i próbujesz ponownie](eliksir/eliksir.md)
