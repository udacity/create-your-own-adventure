To dobra decyzja, bo pragnienie coraz bardziej si� wzmaga. Co z tego, �e nie masz na sobie
spodni? Kogo to obchodzi, skoro jak widzisz, w tej krainie wszyscy chodz� bez majtek.
W Biedronce litr dobrej p�s�odkiej Kadarki kosztuje 10 z�. To niewiele, za tak
dobre wino i przy okazji jest jego tyle, �e mo�esz podzieli� si� z nim z wszystkimi krasnoludkami,
skrzatami i dobrymi duszkami, kt�re zamieszkuj� poblisk� ��k�, tam gdzie jest uj�cie wody miejskiej.
W pobliskiej Biedronce kupujesz Kadark�.

Mo�e masz ochot� przej�� si� na poblisk� ��k�?

Co robisz?


[Wracasz na pocz�tek](../ptasieMleczko.md)

[Jeszcze raz chcesz to sobie przemy�le�](./kadarka.md)

[Idziesz na ��k�](laka/laka.md)

[Idziesz za sklep](zaSklepem/zaSklepem.md)

