Horky Porky Dorky Senor Morky Dorky Porky McJorky Forty porty.
Gesundtite.
Monjamonjamonjamon!