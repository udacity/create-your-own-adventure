Bo Bah Bah Bah boo. Boop Doop do wap pa dap. De De De da do.
From da la fram, cram de la cram. Hip hop de pop.
Trip tra da la tralalala, "enter if you dare". No la
compra a la buscara en la entuentra con el avión.