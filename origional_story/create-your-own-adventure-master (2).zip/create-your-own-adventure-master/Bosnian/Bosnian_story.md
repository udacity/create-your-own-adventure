GORČIN

Ase ležit
Vojnik Gorčin
U zemlji svojoj
Na baštini
Tuždi

Žih
A smrt dozivah
Noć i dan

Mrava ne zgazih
U vojnike
Odoh

Bil sam
U pet i pet vojni
Bez štita i oklopa
E da ednom
Prestanu
Gorčine

Zgiboh od čudne boli

Ne probi me kopje
Ne ustreli strijela
Ne posječe sablja

Zgiboh od boli
Nepreboli
Volju
A djevu mi ugrabiše
U robje

Ako Kosaru sretnete
Na putevima

Molju

Skažite
Za vjernost
Moju

Djevu idem traziti
crnom dolinom
mrske ljude poraziti

Click [here](http://www.spiritofbosnia.org/volume-2-no-3-2007-july/gorcin/) for English version
