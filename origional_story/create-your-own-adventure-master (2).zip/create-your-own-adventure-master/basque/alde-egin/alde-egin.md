Pertsona arraroari zure gaztelutik alde egiteko esan diozu eta bera zuri irainka hasi da.

Harresiaren ateak itxi eta gero barrura sartzen zara, eta telebista ikusten hasten zara. 

Bat-batean, albisteetan ikusten duzun pertsona batek urrezko gaztainak saltzen hari zela gaztelu guztietan.

Zer egiten duzu orain?

[Pertsona arraroaren bila joan zaldiz.](zaldi/zaldi.md)

[Pertsona arraroari deitu harresiaren gainetik oihu.](oihu/oihu.md)
