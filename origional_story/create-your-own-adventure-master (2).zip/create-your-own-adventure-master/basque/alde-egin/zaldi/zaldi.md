Bi ordu geroago topatzen zara gizon arraroarekin azkenean eta esaten diozu:
