Gizon arraroak gaztainak bere etxe ondoan dagoen gaztainondotik hartu dituela esaten dizu.
