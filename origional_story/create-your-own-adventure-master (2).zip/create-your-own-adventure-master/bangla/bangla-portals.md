http://www.pipilika.com/

http://www.somewhereinblog.net/

http://www.priyo.com/

http://www.google.co.in/

বাংলায় পড়ুন [এখানে](https://roar.media/bangla/)