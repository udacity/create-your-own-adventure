Jednog jutra, probudis se u cudnoj sobi za sidovima od sljezovih slatkisa.

Sljezovih slatkisa je mnogo i izgledaju jako ukusno.

Na sebi nosis neudobnu koznu jaknu

U jakni pronalazis upaljac, vilicu i konop.

Cini ti se da te netko promatra

Kad pogledas na stranu, sljezova ruka ti pokusava zgrabiti upaljac/

Napokon shvatis da je sljez samosvjestan!

Brzo zgrabiš upaljač, prestravljeno trčeći prema najbližim vratima.

Vani pada kisa.

Istrcis van, sljez se rastopi.
