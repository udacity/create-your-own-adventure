Du opdager, at dine gulerødder er klare til at blive høstet. Du bliver høster
gulerødderne og bager en
[gulerodskage] (http://www.arla.dk/opskrifter/gulerodskage/).
