Du stopper stille og roligt bilen i vejkanten. 
