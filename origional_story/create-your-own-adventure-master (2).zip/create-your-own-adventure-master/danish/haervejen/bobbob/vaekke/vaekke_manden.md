Du siger, fast og højt, "Hallo, Her! Kan du høre mig?"
