Nøglen sidder i tændingen, så du kører tilfreds afsted. Efter et stykke tid hører du en mumlen fra bagsædet.
Du opdager bestyrtet at der ligger en høj, tynd og bleg mand og taler i søvne. Han siger "Bob bob bob".

Hvad gør du?

[Vækker manden](vaekke/vaekke_manden.md)

[Stopper stille og roligt i vejkanten](stop/stop_i_vejkanten.md)

[Kører videre og lader manden sove](videre/koer_og_lad_sove.md)

