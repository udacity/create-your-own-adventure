Du vælger at køre videre, men kører forsigtigt så du ikke kommer til at vække manden på bagsædet. 
Han siger fortsat "bob bob bob" af og til.  
