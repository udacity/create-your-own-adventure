Du samler cyklen op, og nu går det væsentligt hurtigere, omend lettere
knirkende. Vejen bugter sig langsomt ned gennem landskabet, langs marker,
gårde og landsbyer.

Dagen er nu ved at være på hæld, og du kan ikke se noget der kunne ligne et
gæstgiveri i nærheden.

Hvad gør du?

[Holder en fed provinsfest for dig selv](https://www.youtube.com/watch?v=9_xIoJzZtKg).

[Går i panik, smider cyklen og bryder ud i en erotisk, 
dog klodsede dans sammen med en tilfældig 
forbipasserende](https://www.youtube.com/watch?v=nYbI07YBFuI).
