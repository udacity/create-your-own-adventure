Nagpatuloy ka sa paghanap ng pindutan at nang ito'y iyong nahanap, agad mo itong
pinindot. Nabulag ka saglit sa liwanag ng nag-iisang bumbilya at inangat mo ang
iyong kamay pra subukang takpan ang iyong mata. Sa pag angat mo ng kamay mo, 
napansin mong may kakaibang hugis na mistulang nakadikit sa iyong palad.
Sa puntong iyon, nalaman mo na hindi lang ikaw na nasa loob ng kwarto.

Subukang [durugin ang ipis](http://www.publicdomainpictures.net/pictures/60000/velka/cockroach.jpg).

[Tapakan ang ipis habang nag iisip](durog/durog.md)

Tigtigin ang kamay para maalis ang ipis at [kumaripas pabalas ng kwarto] (../../salamat.md).