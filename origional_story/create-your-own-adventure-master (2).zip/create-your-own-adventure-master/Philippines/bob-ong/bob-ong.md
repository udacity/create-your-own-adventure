Ano ang unang libro ni Bob Ong ang nabasa mo? 
1. ABNKKBSNPLAKo?! (Mga Kwentong Chalk ni Bob Ong)
2. Macarthur
3. Stainless Longganisa
4. Alamat ng Gubat
5. Bakit Baliktad Magbasa Ng Libro Ang Mga Pilipino?

Bakit mo binasa ang libro ni Bob Ong?
1. Dahil siya ay dating web developer
2. May nagpahiram sa iyo ng libro
3. Na engganyo kang basahin dahil "uso"
4. Wala lang

Sino ang mas paborito mo si Bob Ong o Jericho Rosales?

Nahilo ka na ba? Sige ito ang gamot [gamot] (../salamat.md) sa hilo. 
