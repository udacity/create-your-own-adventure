Para sa mga pagbabagong nagaganap sa ating bayan,

Na minsa'y hindi na namamalayan

Kapwa Pilipino na ang mga naglalaban-laban

Nakalimutan na ba natin ang ating bayan?

Tandaan, itatak sa ating ulo

Ang tanging kakampi ng Pilipino ay kapwa Pilipino

Anumang desisyon natin para sa bayang ito

Ang makikinabang at maghihirap ay walang iba kundi tayo

[Salamat.](../salamat.md)
