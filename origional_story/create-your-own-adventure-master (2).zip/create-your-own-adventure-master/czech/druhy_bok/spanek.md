Spíš, ale ve spánku si uvědomuješ sama sebe. Divné. Dokážeš ovlivnit své myšlenky. Co uděláš?
Spoustu lidí chce létat a ve spánku, pokud jsme si vědomi sami sebe, můžeme. Existuje 
i odborný termín - anglicky lucid dreaming.

[Pokusíš se usnout ve snu](sen/ve_snu.md)