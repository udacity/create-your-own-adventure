Z rozespalosti to trochu přeženeš.

Zabereš víc, než jsi měl v úmyslu a málem si uřežeš poslední článek ukazováčku.

K nechutně sladkému smradu marshmelounů se připojí nasládlý pach čerstvé krve.

["Honem chňapneš jednoho maršmeláka, uděláš v něm díru, nasadíš ho na krvácející prst a zapalovačem stmelíš"](bandaz/marsmelak.md)