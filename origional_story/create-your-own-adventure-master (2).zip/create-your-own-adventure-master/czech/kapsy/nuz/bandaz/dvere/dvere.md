Projdeš dveřmi azjistiš že je tam hromada maršmeloidních humanoidu 
kteří vypadají jako panaček mischelin obraceny naruby 
a otočený vzhůru nohama. Jeden znich se otoči a vydase tvím směrem.
Co udělaš? Vytasíš nuž? Začneš zdrhat?
Nebo provedeš uplně něco jiného?
