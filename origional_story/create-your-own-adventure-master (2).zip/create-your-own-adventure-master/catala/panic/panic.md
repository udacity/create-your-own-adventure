De sobte no pots respirar, els pulmons se't fan petits i no t'entra l'aire.

Notes com tot el cos se't paralitza de por. 

Però com redimonis has arribat allà? 

L'últim que recordes és que estaves a casa, tumbat al teu llit, llegint
abans d'anar a dormir.

I pensant en llegit... on està el llibre?

Però redimoniiiiis!!! A qui li importa on està el llibre en aquest moment?
Això no és important en aquest moment, t'has de centrar i pensar en on estàs, 
com hi has arribat i com redimooooooniiiiis sortiràs d'allà.

Però... i el llibre?

Si em surto d'aquesta, prometo no tornar a llegir Kafka abans de dormir.

Al sortir a corre cuita de l'habitació, em trobo de sobte
[al damunt d'una roca al mig d'un bosc ben fosc.](../troll/troll.md)
