Agafes una cullerada i bufes per a que es refredi per� no controles la teva for�a
i tot el contingut de la cullera surt volant i queda escampat pel terra i les parets de l'habitaci�.
L'arr�s bullent comen�a a derretir les parets i s'obre un forat cap a un altre m�n.

