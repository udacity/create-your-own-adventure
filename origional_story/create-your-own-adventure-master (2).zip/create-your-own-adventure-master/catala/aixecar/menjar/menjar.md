Mentre menjes la xocolata, et sopréns perque trobes que te gust de pollastre, 
i comences a sospitar que potser has trobat una escletxa a Matrix.
De sobte algú pica a la porta.

Toc Toc Toc! Que fàs?