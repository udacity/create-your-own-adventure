T'aixeques del llit i recorres l'habitació intentant recordar on ets

quan de sobte els mobles començen a convertir-se en xocolata.

Què fas?

[agafes el mòbil per fer una foto](../pessigar-se/foto/foto.md)

[busques una sortida](../sortir/sortir.md)

[Intentes convertirte en super guerrer](guerrer/guerrer.md)

[Agafes un troç de taula i te'l comences a cruspir](menjar/menjar.md)