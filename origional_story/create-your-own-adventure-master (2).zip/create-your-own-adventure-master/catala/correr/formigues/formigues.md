Les petites formiguetes a l'estiu,
quan el blat ja està segat, ben lligat i apilotat,
surten arrengleredetes del seu niu, fent xiu-xiu, fent xiu-xiu...

I et poses a fer-li pessigolles a la teva parella!