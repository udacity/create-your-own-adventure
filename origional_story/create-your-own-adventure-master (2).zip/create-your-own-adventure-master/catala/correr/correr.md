La ostia que et fots és de campionat!

Que no saps que les parets no poden ser de núvol de sucre?

És clar que no, si no les formigues t'entrarien a casa ;-P

Què fas?

[Et poses a buscar formigues](formigues/formigues.md)