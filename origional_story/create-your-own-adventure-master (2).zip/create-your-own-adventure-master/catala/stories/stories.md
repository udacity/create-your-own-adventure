Busques a la tauleta de nit el teu móvil. Et costa trobar-ho pero per fi, 
mig dormit encara et dones conta que el móvil també esta fet de núvols de sucre...

I ara... què vols fer?

[Menjar el móvil](menjar_movil/menjar_movil.md)

[Activo el móvil i obro la app de camera](app_camera/app_camera.md)

[Em poso a dormir](../dormir/dormir.md)