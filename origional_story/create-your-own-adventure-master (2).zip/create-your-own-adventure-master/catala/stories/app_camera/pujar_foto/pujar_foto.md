Li dones al botó de compartir i veus els teus seguidors 
aumentar molt ràpidament, a cada nou seguidor cau un núvol 
de sucre del sostre i en pocs instants et trobes a sota d'una muntanya 
de núvols de sucre que t'impedeix moure't.

Ara, feliç de ser la persona més popular del moment, tornes a dormir.