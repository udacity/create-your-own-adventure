El móvil de núvols de sucre és incríble... te uns efectes psicodélics que
ensenyen criatures virtuals en realitat augmentada sobre la aplicació de camera. 
Quan toques sobre les criatures a la pantalla es converteixen en reals, 
es la millor foto que has fet en anys, segur que consegueixes un millió de nous 
seguidors despres de pujar la foto.

I ara... què vols fer?

[Pujar la foto](pujar_foto/pujar_foto.md)

[Em poso a dormir](../../dormir/dormir.md)