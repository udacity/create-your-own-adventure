El móvil de núvols de sucre té un sabor espectacular i t'ompla la panxa ràpidament.

I ara... et vols menjar les parets?

[Comences a menjar sucre desesperadament](../../menjar/menjar.md)

[Et poses a dormir](../../dormir/dormir.md)