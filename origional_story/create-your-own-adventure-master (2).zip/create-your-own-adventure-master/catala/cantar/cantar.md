La pluja que cau sobre la tenda et desperta.
El teu company de tenda havia deixat una bossa plena de llaminadures
prop del teu cap, deu ser això el que t'ha fet somniar amb les parets de sucre...

I ara... què vols fer?

[Tasto una llaminadura](tastar/tastar.md)

[Surto de la tenda](sortir_tenda/sortir_tenda.md)

[Em pose a dormir](../dormir/dormir.md)