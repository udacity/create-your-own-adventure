T'acostes a l'horitzó i tastes el caramel que cau del sol.
Té un gust deliciós i sorprenent, com corrents de calor pessigollant entre les teves dents.
Quan te n'has fartat t'adones que rere l'horitzó no hi ha més caramel: només una llarga caiguda al buit.

[Estàs tan tip de caramel, que decideixes deixar-te caure al buit. Fins que xoques contra el fons...](../../../aixecar/aixecar.md)

[Busques alguna forma de parar la caiguda. Trobes una gran roca i et puges a sobre](../../../troll/troll.md)
