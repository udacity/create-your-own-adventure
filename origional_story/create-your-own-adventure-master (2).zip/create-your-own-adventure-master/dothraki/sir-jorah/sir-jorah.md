Mae athzhili Daenerys evoon. Vosma yer laz [athfiezi] (https://media.giphy.com/media/3o6EhO0Q1RYyWYMLUQ/giphy.gif) .
