Sekke zichome, toki tokik. [Esemrasali] (https://media.giphy.com/media/BZVuzQA6ehO2A/giphy.gif)
