...السلام عليكم و رحمة الله و بركاته...

هذة اول مشاركة باللغة العربية 
تمنياتي الى كل من قرأ هذا الملف بالاستفادة الكاملة من هذا التدريب
بعد ان انتهيت من هذا السياق حول استعمل جيت هب ماذا تريد ان تفعل؟

[انام](sleep/sleep.md)

[اريد ان اتعلم المزيد](learn/learn.md)

[اريد ان احلم](dream/dream.md)

[ أريد أن آكل](http://www.otlob.com/ar)

[وظيفة](Job/Job.md)

[اقرأ](read/read.md)

[أريد أن أحصل على Nanodegree](https://www.udacity.com/nanodegree)

 [online](learn/learn.md) عايز اعرف اسماء مواقع  كورسات  

 [freelancer](learn/learn.md) عايز اعرف اسماء مواقع  كورسات فرى لانس

[قرار شجاع](tough-decision/tough-decision.md)

[لتنبهر](amazed/amazed.md) توقف لحظة 

هذه التجربة رائعة 

[أحب هذا الكورس](https://www.udacity.com/course/android-developer-nanodegree-by-google--nd801)

[سي يسيس] (https://www.youtube.com/watch?v=EUw-zTz8cU8)

[أريد أن أكون ناجح](success/paths-to-success.md)