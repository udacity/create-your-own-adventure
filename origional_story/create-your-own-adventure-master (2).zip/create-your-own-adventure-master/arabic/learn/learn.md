اذا قررت ان تكمل الالتعلم فانه عليك ان تبحث عن موضوع مكمل لموضوع السياق الماضي، هل تعرف لماذا؟
لانه يجب عليك الاستفاده من السياق الماضي وتطوير قدراتك فيه لذا ماذا تتوقع ان تفعل الان؟
قال صلى الله عليه وسلم من سلك طريقاً يلتمس فيه علماً سهل الله له طريقاً الى الجنة
[و لماذا التعلم ](whylearning/speculate.md)

 امثلة مواقع الكورسات اونلاين :

-Udacity
-coursera
-Udemy
-Khan Academy
-thenewboston

وفيه كتير بس انت عليك تدور

freelancing اشهر مواقع العمل الحر 

-[UpWork](https://www.upwork.com/)

-[freelancer](https://www.freelancer.com/)

ولكن قبل ذلك، عليك أن تحدد ماذا تريد أن تتعلم:

- [البرمجة](whattolearn/programming/programming.md)

- [الرسم](whattolearn/drawing/drawing.md)

- [التصوير](whattolearn/photography/photography.md)

- [الطهي](whattolearn/cooking/cooking.md)

- [الرياضيات](https://www.khanacademy.org)

- [أخرى](whattolearn/other/other.md)




